// FEITO POR ANDREI RAMOS LOPES
#include "arvore.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

TNode *abpCreate(void *elm) {
  TNode *t = (TNode *)malloc(sizeof(TNode));
  t->data = elm;
  t->l = NULL;
  t->r = NULL;
  return t;
}

int abpDestroy(TNode *t) {
  if (t != NULL) {
    if (t->l == NULL && t->r == NULL && t->data == NULL) {
      free(t);
      return true;
    }
  }
  return false;
}

void *abpQuery(TNode *t, void *key, int (*cmp)(void *, void *)) {
  int stat;
  if (t != NULL) {
    stat = cmp(key, t->data);
    if (stat == 0) {
      return t->data;
    } else if (stat < 0) {
      return abpQuery(t->l, key, cmp);
    } else {
      return abpQuery(t->r, key, cmp);
    }
  }
  return NULL;
}

TNode *abpInsert(TNode *t, void *data, int (*cmp)(void *, void *)) {
  TNode *newnode;
  if (t != NULL) {
    int data1=*(int *)t->data;
    if (cmp(data, t->data) <= 0) {
      t->l = abpInsert(t->l, t->data, cmp);
      int data2=*(int *)t->l->data;
      return t;
    } else {
      t->r = abpInsert(t->r, t->data, cmp);
      int data3=*(int *)t->r->data;
      return t;
    }
  }
  newnode = (TNode *)malloc(sizeof(TNode));
  if (newnode != NULL) {
    newnode->data = data;
    newnode->l = NULL;
    newnode->r = NULL;
    return newnode;
  }
  return NULL;
}

TNode *minValueNode(TNode *abp) {
  TNode *current = abp;
  if (current == NULL) {
    return NULL;
  }
  while (current && current->l != NULL)
    current = current->l;
  return current;
}
TNode *maxValueNode(TNode *abp) {
  TNode *current = (TNode *)malloc(sizeof(TNode));
  current = abp;
  if (current == NULL || abp == NULL) {
    return NULL;
  }
  while (current && current->r != NULL) {
    current = current->r;
  }
  return current;
}

TNode *abpRemove(TNode *t, void *key, int (*cmp)(void *, void *), void **data) {
  void *data2;
  int stat;
  if (t != NULL) {
    stat = cmp(data, t->data);
    if (stat < 0) {
      t->l = abpRemove(t, key, cmp, data2);
      return t;
    } else if (stat > 0) {
      t->r = abpRemove(t, key, cmp, data2);
      return t;
    } else {
      if (t->l == NULL && t->r == NULL) {
        data = t->data;
        free(t);
        return NULL;
      } else if (t->l == NULL) {
        TNode *aux = t->r;
        data = t->data;
        free(t);
        return aux;
      } else if (t->r == NULL) {
        TNode *aux = t->l;
        data = t->data;
        free(t);
        return aux;
      } else {
        data = t->data;
        t->l = abpRemove(t, (void *)maxValueNode(t->l), cmp, &data2);
        t->data = data2;
        return t;
      }
    }
  }
  data = NULL;
  return NULL;
}

void visitInt(void *num) { 
  printf("%d\n", *(int *)num); 
}

void abpListAll(TNode *t, void (visit)(void *)) {
  if (t != NULL) {
    int data1=*(int *)(t->data);
    abpListAll(t->l, visit);
    visit(t->data);
    abpListAll(t->r, visit);
  }
}

// TNode *abpRemoveMaior(TNode *t, int (*cmp)(void *, void *), void *data) {
//   void *data2;
//   if (t != NULL) {
//     if (t->r != NULL) {
//       t->r = abpRemoveMaior(t, cmp, &data2);
//     } else {
//       if (t->l != NULL) {
//         TNode *aux = t->l;
//         data = t->data;
//         free(t);
//         return aux;
//       } else {
//         data = t->data;
//         free(t);
//         return NULL;
//       }
//     }
//   }
//   data = NULL;
//   return NULL;
// }

// gCofo *gcofCreate(int max_itens) {
//   gCofo *gc;
//   if (max_itens > 0) {
//     gc = (gCofo *)malloc(sizeof(gCofo));
//     if (gc != NULL) {
//       gc->item = (void **)malloc(sizeof(void *) * max_itens);
//       if (gc->item != NULL) {
//         gc->numItens = 0;
//         gc->maxItens = max_itens;
//         gc->atual = -1;
//         return gc;
//       }
//       free(gc);
//     }
//   }
//   return NULL;
// }

// int gcofDestroy(gCofo *gc) {
//   if (gc != NULL) {
//     if (gc->numItens == 0) {
//       free(gc->item);
//       free(gc);
//       return 1;
//     }
//   }
//   return 0;
// }

// int gcofInsert(gCofo *gc, void *item) {
//   if (gc != NULL) {
//     if (gc->numItens < gc->maxItens) {
//       gc->item[gc->numItens] = item;
//       gc->numItens++;
//       return 1;
//     }
//   }
//   return 0;
// }

// int gcofAll(gCofo *gc) {
//   int i;
//   if (gc != NULL) {
//     Aluno *aluno = (Aluno *)malloc(sizeof(Aluno));
//     if (gc->numItens > 0 && aluno != NULL) {
//       i = 0;
//       while (i < gc->numItens) {
//         aluno = gc->item[i];
//         printf("\nElemento número %d:\n", i + 1);
//         printf("- Matrícula: %d\n", aluno->matricula);
//         printf("- Nome completo: %s\n", aluno->nome_completo);
//         printf("- CR: %f\n\n", aluno->cr);
//         i++;
//       }
//       return 1;
//     }
//   }
//   return 0;
// }

// void *gcofQuery(gCofo *gc, void *key, int (*cmp)(void *, void *)) {
//   int i;
//   int data;
//   int stat = 0;
//   if (gc != NULL) {
//     if (gc->numItens > 0) {
//       i = 0;
//       while (i < gc->numItens && stat != 1 && gc->numItens > 1) {
//         stat = cmp(gc->item[i], key);
//         i++;
//       }
//       if (stat == 1) {
//         return gc->item[i];
//       }
//     }
//   }
//   return NULL;
// }

// void *gcofRemove(gCofo *gc, void *key, int (*cmp)(void *, void *)) {
//   int i;
//   void *data;
//   int stat;
//   if (gc != NULL) {
//     if (gc->numItens > 0) {
//       i = 0;
//       stat = cmp(key, gc->item[i]);
//       while (i < gc->numItens && stat != 1) {
//         i++;
//         stat = cmp(key, gc->item[i]);
//       }
//       if (stat == 1) {
//         data = gc->item[i];
//         for (int j = i; j < gc->numItens; j++) {
//           gc->item[j] = gc->item[j + 1];
//         }
//         gc->numItens--;
//         return data;
//       }
//     }
//   }
//   return NULL;
// }

// int gcofClear(gCofo *gc, int (*cmp)(void *, void *)) {
//   if (gc != NULL) {
//     if (gc->numItens > 0) {
//       int i;
//       for (i = gc->numItens - 1; i >= 0; i--) {
//         gcofRemove(gc, gc->item[i], cmp);
//       }
//       return 1;
//     }
//   }
//   return 0;
// }